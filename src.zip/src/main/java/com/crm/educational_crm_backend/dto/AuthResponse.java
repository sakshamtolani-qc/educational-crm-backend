package com.crm.educational_crm_backend.dto;

public class AuthResponse {
    private String token;
    private String tokenType = "Bearer";
    private String username;
    private String role;

    public AuthResponse(String token, String username, String role) {
        this.token = token;
        this.username = username;
        this.role = role;
    }

    // Getters only (response object usually immutable)
    public String getToken() { return token; }
    public String getTokenType() { return tokenType; }
    public String getUsername() { return username; }
    public String getRole() { return role; }
}
