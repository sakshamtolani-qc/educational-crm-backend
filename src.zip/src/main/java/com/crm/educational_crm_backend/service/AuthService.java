package com.crm.educational_crm_backend.service;

import com.crm.educational_crm_backend.dto.AuthResponse;
import com.crm.educational_crm_backend.entity.User;
import com.crm.educational_crm_backend.repository.UserRepository;
import com.crm.educational_crm_backend.security.JwtTokenProvider;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;

    public AuthService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       JwtTokenProvider jwtTokenProvider) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    // Register a new user
    public User register(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    // Login user and generate JWT
    public Optional<AuthResponse> login(String email, String rawPassword) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isPresent() && passwordEncoder.matches(rawPassword, userOpt.get().getPassword())) {
            User user = userOpt.get();
            String token = jwtTokenProvider.generateToken(user.getEmail(), user.getId(), user.getRole());
            return Optional.of(new AuthResponse(token, user.getUsername(), user.getRole()));
        }
        return Optional.empty();
    }
}
