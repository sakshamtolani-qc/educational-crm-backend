package com.crm.educational_crm_backend.controller;

import com.crm.educational_crm_backend.dto.AuthResponse;
import com.crm.educational_crm_backend.dto.LoginRequest;
import com.crm.educational_crm_backend.entity.User;
import com.crm.educational_crm_backend.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody User user) {
        User registeredUser = authService.register(user);
        return ResponseEntity.ok(registeredUser);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        Optional<AuthResponse> loginOpt = authService.login(loginRequest.getEmail(), loginRequest.getPassword());

        if (loginOpt.isPresent()) {
            return ResponseEntity.ok(loginOpt.get());
        } else {
            return ResponseEntity.status(401).body(new ErrorResponse("Invalid credentials"));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        return ResponseEntity.ok("Logged out successfully");
    }

    // ErrorResponse DTO for consistent API responses
    static class ErrorResponse {
        private String message;
        public ErrorResponse(String message) { this.message = message; }
        public String getMessage() { return message; }
    }
}
