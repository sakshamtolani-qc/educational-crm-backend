package com.crm.educational_crm_backend.controller;

import com.crm.educational_crm_backend.dto.UserResponse;
import com.crm.educational_crm_backend.entity.User;
import com.crm.educational_crm_backend.exception.UserNotFoundException;
import com.crm.educational_crm_backend.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // List all users (Admin only)
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<UserResponse>> getAllUsers() {
        List<UserResponse> users = userService.getAllUsers().stream()
                .map(u -> new UserResponse(
                        u.getId(), u.getUsername(), u.getEmail(),
                        u.getFirstName(), u.getLastName(), u.getRole()))
                .collect(Collectors.toList());
        return ResponseEntity.ok(users);
    }

    // Get user by ID (Authenticated users)
    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<UserResponse> getUserById(@PathVariable UUID id) {
        User user = userService.getUserById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + id));
        return ResponseEntity.ok(new UserResponse(
                user.getId(), user.getUsername(), user.getEmail(),
                user.getFirstName(), user.getLastName(), user.getRole()));
    }

    // Update user profile (Self or Admin)
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or #id == principal.id")
    public ResponseEntity<UserResponse> updateUser(@PathVariable UUID id, @RequestBody User user) {
        user.setId(id);
        User updated = userService.updateUser(user);
        return ResponseEntity.ok(new UserResponse(
                updated.getId(), updated.getUsername(), updated.getEmail(),
                updated.getFirstName(), updated.getLastName(), updated.getRole()));
    }

    // Delete user (Admin only)
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> deleteUser(@PathVariable UUID id) {
        userService.deleteUser(id);
        return ResponseEntity.ok("User deleted successfully!");
    }

    // Update user role (Admin only)
    @PutMapping("/{id}/role")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserResponse> updateUserRole(@PathVariable UUID id, @RequestParam String role) {
        User user = userService.getUserById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + id));
        user.setRole(role);
        User updated = userService.updateUser(user);
        return ResponseEntity.ok(new UserResponse(
                updated.getId(), updated.getUsername(), updated.getEmail(),
                updated.getFirstName(), updated.getLastName(), updated.getRole()));
    }
}
